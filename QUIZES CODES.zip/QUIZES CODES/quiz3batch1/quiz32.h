
#ifndef QUIZ32_H
#define QUIZ32_H
class george{
	public:	
		void input();
		void execute();
		void append();
};
#endif
