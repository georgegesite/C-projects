#ifndef QUIZ3_H
#define QUIZ3_H
class george{
	public:
		
		void input();
		void execute();
		void finder();
		void keep();
		void output();
};
#endif


